from django.shortcuts import render
from .models import Blog
# Create your views here.
#function and class base views, template inherit, contact us = POST, 
 
def Blog(request):
    blog = Blog.objects.all()
    context = {
        'blog':blog
    }
    return (request, "blog.html", context)

