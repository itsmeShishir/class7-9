from core import views
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", views.Home),
    path("about/", views.AboutUs),
    path("contact/", views.Contact),
    path("blog/<int:blogid>", views.Blog), #dynamic routes
    path("", )
]

#CLB2770E7F
